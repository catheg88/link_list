def new_link
	Link.new 
end